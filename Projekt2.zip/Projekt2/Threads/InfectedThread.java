package GUI.Projekt2.Threads;

import GUI.Projekt2.Gra;

import javax.swing.*;
import java.time.LocalTime;

public class InfectedThread extends Thread {
    public static int infectedPeople = 0, deadPeople = 0, recoveredPeople = 0;
    public JLabel infected, deaths, recovered, points;
    public static int levelsCase, range = 6, min = 12, rand3;
    public Gra gra = new Gra();

    public InfectedThread(int wrt) {
        this.levelsCase = wrt;
    }

    @Override
    public void run() {


        switch (levelsCase) {
            case 1:
                //hard
                while (recoveredPeople < 500000 && infectedPeople < 2500000) {

                    rand3 = (int) ((Math.random() * range) + min);
                    int rand = (int) ((Math.random() * 364) + 135);
                    int rand2 = (int) ((Math.random() * 35460) + 58150);

                    infectedPeople += rand2;
                    deadPeople += rand;
                    recoveredPeople += rand3;


                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    addingLabels(infectedPeople, deadPeople, recoveredPeople, infected, deaths, recovered);

                }

                break;
            case 2:
                //medium
                while (recoveredPeople < 400000 && infectedPeople < 2500000) {

                    int rand = (int) ((Math.random() * 240) + 135);
                    int rand2 = (int) ((Math.random() * 34340) + 46535);
                    rand3 = (int) ((Math.random() * range) + min);

                    infectedPeople += rand2;
                    deadPeople += rand;
                    recoveredPeople += rand3;

                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    addingLabels(infectedPeople, deadPeople, recoveredPeople, infected, deaths, recovered);

                }
                break;
            case 3:
                //easy
                while (recoveredPeople < 300000 && infectedPeople < 2500000) {

                    int rand = (int) ((Math.random() * 130) + 115);
                    int rand2 = (int) ((Math.random() * 33654) + 35504);
                    rand3 = (int) ((Math.random() * range) + min);


                    infectedPeople += rand2;
                    deadPeople += rand;
                    recoveredPeople += rand3;

                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    addingLabels(infectedPeople, deadPeople, recoveredPeople, infected, deaths, recovered);

                }
                break;


        }


    }

    public void addingLabels(int infectedPeople, int deadPeople, int recoveredPeople, JLabel iLabel, JLabel dLabel, JLabel recovered) {
        iLabel.setText(String.valueOf(infectedPeople));
        dLabel.setText(String.valueOf(deadPeople));
        recovered.setText(String.valueOf(recoveredPeople));

        int wrt = Gra.punkty + rand3;

        Gra.punkty = wrt;

        points.setText(String.valueOf(wrt));


    }
}
