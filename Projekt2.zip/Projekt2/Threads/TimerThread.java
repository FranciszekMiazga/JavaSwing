package GUI.Projekt2.Threads;

import javax.swing.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public class TimerThread extends Thread {

    public LocalTime lt;
    public JLabel jl;


    public TimerThread(LocalTime time) {
        this.lt = lt;
    }

    @Override
    public void run() {
//lt.getMinute()!=0 && lt.getSecond()!=0
        lt = LocalTime.parse("00:15:00.00");
        while (lt.getMinute() != 0 || lt.getSecond() != 0) {

            LocalTime tmp = lt.minusSeconds(1);


            //tmp.minusHours(1);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            lt = tmp;
            //System.out.println(lt);
            settingTimer(jl, lt);
        }

    }

    public void settingTimer(JLabel jLabel, LocalTime tmp) {
        jLabel.setText(" " + String.valueOf(tmp));
    }

    public LocalTime getTime() {
        return lt;
    }
}
