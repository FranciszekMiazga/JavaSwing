package GUI.Projekt2;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            Menu menu = new Menu();
            menu.setTitle("Menu");

        });
    }
}
