package GUI.Projekt2;

import GUI.Projekt2.Ranking.RankingModel;
import GUI.Projekt2.Ranking.RankingRenderer;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddNewListener implements ActionListener {
    private String wrt;
    private String username;
    private JList jList;
    public JTextField nazwa;


    public AddNewListener(String wr, JList jList) {
        this.wrt = wr;
        this.jList = jList;

    }

    @Override
    public void actionPerformed(ActionEvent e) {


        RankingModel rank = (RankingModel) jList.getModel();

        System.out.println(wrt + " elo");
        //rank.add(wrt);
    }

}
