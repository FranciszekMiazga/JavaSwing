package GUI.Projekt2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Difficulty_Level extends JPanel {

    public Difficulty_Level() {


        setLayout(new BorderLayout());


        JPanel levelsPanel = new JPanel();
        JPanel bottom = new JPanel();
        JPanel top = new JPanel();

        JButton easy = new JButton("Easy");
        changeFeatureofButton(easy);

        JButton medium = new JButton("Medium");
        changeFeatureofButton(medium);

        JButton hard = new JButton("Hard");
        changeFeatureofButton(hard);


        SpringLayout sl = new SpringLayout();
        levelsPanel.setLayout(sl);

        ImageIcon ii = new ImageIcon("src/GUI/Projekt2/Icons/pandemic.png");
        JLabel icon = new JLabel();


        levelsPanel.setLayout(new BorderLayout());
        icon.setIcon(ii);
        levelsPanel.add(icon, BorderLayout.PAGE_END);


        levelsPanel.add(easy, BorderLayout.LINE_START);
        levelsPanel.add(medium, BorderLayout.CENTER);
        levelsPanel.add(hard, BorderLayout.LINE_END);
        //levelsPanelmain.setLayout(card);
        Gra gra = new Gra();
        easy.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                Menu.changingVariable(1);
                removeAll();
                add(gra);
                invalidate();
                validate();
                int wrt = 3000;
                gra.settingPoints(wrt);
                gra.settingPrzelicznik(1.0);
                gra.settingCase(3);
                gra.setFocusable(true);
                gra.setPreferredSize(new Dimension(1440, 900));


            }
        });
        medium.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                removeAll();
                add(gra);
                invalidate();
                validate();
                int wrt = 2250;
                gra.settingPoints(wrt);
                gra.settingPrzelicznik(1.5);
                gra.settingCase(2);


            }
        });
        hard.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                removeAll();
                add(gra);
                invalidate();
                validate();
                int wrt = 1500;
                gra.settingPoints(wrt);
                gra.settingPrzelicznik(2.0);
                gra.settingCase(1);


            }
        });
        //levelsPanel.setLayout();
        bottom.setPreferredSize(new Dimension(400, 150));
        bottom.setBackground(Color.BLACK);
        top.setPreferredSize(new Dimension(400, 150));
        top.setBackground(Color.BLACK);

        add(bottom, BorderLayout.PAGE_END);

        add(top, BorderLayout.PAGE_START);
        add(levelsPanel, BorderLayout.CENTER);


        levelsPanel.setBackground(Color.RED);


    }

    public void changeFeatureofButton(JButton button) {
        button.setOpaque(true);
        button.setForeground(Color.BLACK);
        button.setPreferredSize(new Dimension(100, 40));
        //button.setContentAreaFilled(false);
        button.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        button.setBackground(Color.RED);
        button.setBorderPainted(true);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }

}
