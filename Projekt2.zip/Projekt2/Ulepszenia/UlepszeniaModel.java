package GUI.Projekt2.Ulepszenia;

import javax.swing.*;
import javax.swing.event.ListDataListener;
import java.io.Serializable;

public class UlepszeniaModel implements ComboBoxModel<String> {

    Ulepszenia ul = new Ulepszenia();
    JLabel[] jLabel;
    public Object selected;
    public static int tmp;


    public UlepszeniaModel(JLabel[] jLabel) {
        this.jLabel = jLabel;

    }


    @Override
    public void setSelectedItem(Object anItem) {
        selected = anItem;
        //return (String)anItem;
    }

    @Override
    public Object getSelectedItem() {
        return selected;
    }

    @Override
    public int getSize() {
        return jLabel.length;
    }

    @Override
    public String getElementAt(int index) {

        return jLabel[index].getText();
    }

    @Override
    public void addListDataListener(ListDataListener l) {


    }

    @Override
    public void removeListDataListener(ListDataListener l) {

    }
}
