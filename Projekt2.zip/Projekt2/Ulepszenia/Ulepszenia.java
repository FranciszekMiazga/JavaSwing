package GUI.Projekt2.Ulepszenia;

import GUI.GUI_wyklad3.Student;

import javax.swing.*;
import java.awt.*;

public class Ulepszenia extends JPanel {
    public JLabel przylbice, zele, leki, maski, szczepionka, szpitale, laboratoria, respiratory, odpornoscSpoleczna;
    public JLabel[] tab;
    public int przylbiceP = 1500, zeleP = 2000,
            lekiP = 3500, maskiP = 4000, szczepionkaP = 4500,
            szpitaleP = 5000, laboratoriaP = 5700, respiratoryP = 7000, odpornoscSpolecznaP = 8400;

    public Ulepszenia() {
        JPanel combo = new JPanel();


//implementacja ulepszen
        //System.out.println("ulepszenia zwykle");
        przylbice = new JLabel(" przyłbice - " + przylbiceP);
        zele = new JLabel(" żele antybakteryjne - " + zeleP);
        leki = new JLabel(" leki - " + lekiP);
        maski = new JLabel(" maski - " + maskiP);
        szczepionka = new JLabel(" szczepionka - " + szczepionkaP);
        szpitale = new JLabel(" szpitale - " + szpitaleP);
        laboratoria = new JLabel(" laboratoria - " + laboratoriaP);
        respiratory = new JLabel(" respiratory - " + respiratoryP);
        odpornoscSpoleczna = new JLabel(" odpornosc spoleczna - " + odpornoscSpolecznaP);


        tab = new JLabel[]{przylbice, zele, leki, maski, szczepionka, szpitale, laboratoria, respiratory, odpornoscSpoleczna};


        //UlepszeniaModel um=new UlepszeniaModel(tabJ);


    }
}
