package GUI.Projekt2;

import GUI.Projekt2.Ranking.RankingView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JFrame {

    public static int width;
    public static int height;
    public static int whatPath;

    public Menu() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        width = (int) screenSize.getWidth();
        height = (int) screenSize.getHeight();
        getPreferredSize();


        JPanel menuPanel = new JPanel();
        JPanel obrazek = new JPanel();
        //JPanel coinsy=new JPanel();
        JPanel mapa = new JPanel();

        //JScrollPane scl=new JScrollPane();

        JButton newGame = new JButton("New Game");
        addFetures(newGame);

        JButton highScores = new JButton("High Scores");
        addFetures(highScores);

        JButton exit = new JButton("Exit");
        addFetures(exit);

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        menuPanel.add(newGame);
        menuPanel.add(highScores);
        menuPanel.add(exit);
        menuPanel.setBackground(Color.black);
        menuPanel.setPreferredSize(new Dimension(400, 90));
        setLayout(new BorderLayout());


        JLabel icon = new JLabel();

        ImageIcon im = new ImageIcon("src/GUI/Projekt2/Icons/plague.jpg");


        obrazek.setBackground(Color.BLACK);
        icon.setIcon(im);
        obrazek.add(icon);

        add(obrazek, BorderLayout.CENTER);
        //imageIcon.setImage(imageIcon);

        add(menuPanel, BorderLayout.PAGE_START);


        obrazek.setLayout(new FlowLayout(FlowLayout.CENTER));


        newGame.addActionListener(new ActionListener() {
            //BoxModel boxModel=new BoxModel();
            Difficulty_Level levels = new Difficulty_Level();


            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                setContentPane(levels);
                invalidate();
                validate();
            }
        });

        highScores.addActionListener(new ActionListener() {
            RankingView rv = new RankingView();

            @Override
            public void actionPerformed(ActionEvent e) {
                setContentPane(rv);
                invalidate();
                validate();
            }
        });


        //menuPanel2.add(scl);
        //menu panel 3, after validate

        getPreferredSize();


        pack();
        setTitle("Menu");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);


        //setExtendedState(JFrame.MAXIMIZED_BOTH);

    }

    @Override
    public Dimension getPreferredSize() {
        //System.out.println("this");


        switch (whatPath) {
            case 0:
                return new Dimension(600, 600);
            case 1:
                System.out.println("this");
                SwingUtilities.updateComponentTreeUI(this);
                return new Dimension(width, height);
        }
        return null;
    }

    public static void changingVariable(int tmp) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        width = (int) screenSize.getWidth();
        height = (int) screenSize.getHeight();

        whatPath = tmp;


        //getPreferredSize();
    }

    public void addFetures(JButton button) {
        button.setOpaque(true);
        button.setForeground(Color.BLACK);
        button.setBackground(Color.RED);
        button.setBorderPainted(false);

    }
}


