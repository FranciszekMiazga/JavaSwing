package GUI.Projekt2;

import GUI.Projekt2.Ranking.RankingModel;
import GUI.Projekt2.Ranking.RankingView;
import GUI.Projekt2.Threads.InfectedThread;
import GUI.Projekt2.Threads.TimerThread;
import GUI.Projekt2.Ulepszenia.Ulepszenia;
import GUI.Projekt2.Ulepszenia.UlepszeniaModel;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.text.DefaultEditorKit;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeListener;
import java.time.LocalTime;
import java.util.List;

public class Gra extends JPanel {

    public static LocalTime localTime;
    public JTextField nazwa, nazwar;
    private UlepszeniaModel ulem;
    private Ulepszenia ulepszenia;
    public static int punkty, counter, thaicount, irancount, chinacount;
    public static double przelicznik;
    public JPanel coinsy, panstwa, transport, mapaP;
    public int wrt;
    public static String tmp6 = "Punkty: " + punkty, username;
    private LocalTime lt;
    JLabel iloscMonet, mapal, nazwal, nazwalr;
    Object s;
    public static JList jList;
    public static String rank;
    public static int infectedCase;
    public JButton ok, ok2;

    public Gra() {


        TimerThread tt = new TimerThread(lt);
        tt.start();


        ulepszenia = new Ulepszenia();
        //setPreferredSize(new Dimension(500,500));
        setLayout(new BorderLayout());


        coinsy = new JPanel();
        JPanel wyjscie = new JPanel();

        JLabel[] tabJ = new JLabel[5];
        JButton exit = new JButton("Exit");
        JButton ranking = new JButton("Ranking");
        JButton kupno = new JButton("Kup ");


        JComboBox<String> ulepszeniaCombo = new JComboBox<>();


        ulem = new UlepszeniaModel(ulepszenia.tab);
        ulepszeniaCombo.setModel(ulem);
        //ulepszeniaCombo.setRenderer(new UlepszeniaRenderer());
        //AddNewListener anl=new AddNewListener(rank,jList);
        wyjscie.add(kupno);

        wyjscie.add(ulepszeniaCombo);
        wyjscie.add(ranking);
        wyjscie.add(exit);
        RankingView rv = new RankingView();
        RankingModel rankingModel = (RankingModel) jList.getModel();


        ok2 = new JButton("OK");

        ranking.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                //new AddNewListener(rank,jList);
                if (counter == 0) {
                    //remove(mapaP);
                    invalidate();
                    validate();
                    nazwalr = new JLabel("wpisz nazwe: ");
                    nazwar = new JTextField();

                    nazwar.setPreferredSize(new Dimension(120, 30));
                    mapaP.add(nazwalr);
                    mapaP.add(nazwar);
                    mapaP.add(ok2);
                    add(mapaP, BorderLayout.CENTER);

                    counter++;

                }

            }
        });

        ok2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (!nazwar.getText().equals("")) {
                    username = nazwar.getText();

                    String levelString;

                    localTime = tt.getTime();
                    double wrt = getPoints() * przelicznik;
                    //rank=username+" , "+wrt;
                    if (przelicznik == 1) {
                        levelString = "EASY";
                    } else if (przelicznik == 1.5) {
                        levelString = "MEDIUM";
                    } else
                        levelString = "HARD";

                    rankingModel.add(username, wrt, localTime, levelString);


                    removeAll();
                    add(rv);
                    invalidate();
                    validate();
                }
            }
        });


        ok = new JButton("OK");

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (counter == 0) {
                    //remove(mapaP);
                    invalidate();
                    validate();
                    nazwal = new JLabel("wpisz nazwe: ");
                    nazwa = new JTextField();

                    nazwa.setPreferredSize(new Dimension(120, 30));
                    mapaP.add(nazwal);
                    mapaP.add(nazwa);
                    mapaP.add(ok);
                    add(mapaP, BorderLayout.CENTER);
                    counter++;
                }
            }
        });


        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!nazwa.getText().equals("")) {
                    String levelString;
                    username = nazwa.getText();
                    double wrt = getPoints() * przelicznik;
                    localTime = tt.getTime();

                    if (przelicznik == 1) {
                        levelString = "EASY";
                    } else if (przelicznik == 1.5) {
                        levelString = "MEDIUM";
                    } else
                        levelString = "HARD";

                    rank = username + " , " + wrt;
                    rankingModel.add(username, wrt, localTime, levelString);

                    System.exit(0);
                }
            }
        });


        //ok.addActionListener(new AddNewListener(rank,jList));

        mapaP = new JPanel();
        setPanelPanstwa();
        add(panstwa, BorderLayout.LINE_START);
        setPanelTransport();
        add(transport, BorderLayout.LINE_END);

        //mapaP.setLayout(new BorderLayout());
        iloscMonet = new JLabel(" " + wrt);
        ImageIcon ipoints = new ImageIcon("src/GUI/Projekt2/Icons/coins.png");
        iloscMonet.setIcon(ipoints);

        coinsy.add(iloscMonet);

        mapal = new JLabel();
        JLabel timer = new JLabel(" ");
        tt.jl = timer;


        ImageIcon itimer = new ImageIcon("src/GUI/Projekt2/Icons/timer.png");
        timer.setIcon(itimer);
        coinsy.add(timer);

        add(coinsy, BorderLayout.PAGE_START);
        coinsy.setLayout(new FlowLayout(FlowLayout.RIGHT));


        add(wyjscie, BorderLayout.PAGE_END);


        //InputMap im=new InputMap();
        //KeyStroke key = KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK|InputEvent.SHIFT_DOWN_MASK);
        //im.put(key, DefaultEditorKit.backwardAction);

        JOptionPane jop = new JOptionPane();

        jop.setMessage("\tGra rozpoczyna się w Chinach w Wuhan.\n" +
                "\tZapobiegnij światowej pandemii.\n\tNaciskaj na przyciski odpowiadające za poszczególne państwa,\n" +
                "\tżeby blokować droge wirusowi, a także\n\twykupuj ulepszenia, aby go pokonać.\nNacisnij na tekst, aby zaczac. ");
        //jop.setPreferredSize(new Dimension(300,300));
        add(jop, BorderLayout.CENTER);

        jop.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                remove(jop);
                ImageIcon mapa = new ImageIcon("src/GUI/Projekt2/Icons/map.jpeg");
                mapal.setIcon(mapa);
                mapaP.add(mapal);
                add(mapaP, BorderLayout.CENTER);
                invalidate();
                validate();
            }
        });


        kupno.setEnabled(false);

        ulepszeniaCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                setPoints();
                //System.out.println(wrt);
                kupno.setEnabled(false);
                if (punkty >= wrt) {
                    kupno.setEnabled(true);

                }
            }

        });
        kupno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkStatus();
                removePoints(wrt);
                kupno.setEnabled(false);
            }
        });


    }


    public int getPoints() {
        return punkty;
    }

    public void setnewLabel(int wrt) {

        //System.out.println("tu");
        remove(mapaP);
        JOptionPane koniec = new JOptionPane();
        koniec.setMessage("Koniec gry. Udalo ci sie przebic bariere " + wrt + " wyzdrowialych.");
        mapaP.add(koniec);
        add(mapaP, BorderLayout.CENTER);
        invalidate();
        validate();
    }

    public void checkStatus() {
        if (wrt == ulepszenia.przylbiceP) {
            InfectedThread.range += 400;
            InfectedThread.min += 400;
        } else if (wrt == ulepszenia.zeleP) {
            InfectedThread.range += 600;
            InfectedThread.min += 700;
        } else if (wrt == ulepszenia.lekiP) {
            InfectedThread.range += 1400;
            InfectedThread.min += 1500;
        } else if (wrt == ulepszenia.maskiP) {
            InfectedThread.range += 2000;
            InfectedThread.min += 2100;
        } else if (wrt == ulepszenia.szpitaleP) {
            InfectedThread.range += 2700;
            InfectedThread.min += 2500;
        } else if (wrt == ulepszenia.szczepionkaP) {
            InfectedThread.range += 3500;
            InfectedThread.min += 3300;
        } else if (wrt == ulepszenia.laboratoriaP) {
            InfectedThread.range += 5200;
            InfectedThread.min += 4000;
        } else if (wrt == ulepszenia.respiratoryP) {
            InfectedThread.range += 7500;
            InfectedThread.min += 7000;
        } else if (wrt == ulepszenia.odpornoscSpolecznaP) {
            InfectedThread.range += 12300;
            InfectedThread.min += 42000;
        }
    }

    public void settingPrzelicznik(double i) {
        przelicznik = i;

    }

    public void removePoints(int tmp) {
        punkty -= tmp;
        changePointsInLabel(punkty);
    }

    public void addPoints(int tmp) {
        punkty += tmp;
        changePointsInLabel(punkty);
    }

    public void adding(List list) {
        list.add(tmp6);
    }

    public void settingPoints(int wrt) {
        punkty = wrt;
        iloscMonet.setText(" " + punkty);

    }

    public void changePointsInLabel(int wrt) {

        iloscMonet.setText(" " + wrt);


    }

    public void setPoints() {
        Object tmp = ulem.selected;


        if (tmp.equals(ulepszenia.laboratoria.getText())) {
            wrt = ulepszenia.laboratoriaP;
        } else if (tmp.equals(ulepszenia.maski.getText())) {
            wrt = ulepszenia.maskiP;
        } else if (tmp.equals(ulepszenia.zele.getText())) {
            wrt = ulepszenia.zeleP;
        } else if (tmp.equals(ulepszenia.przylbice.getText())) {
            wrt = ulepszenia.przylbiceP;
        } else if (tmp.equals(ulepszenia.odpornoscSpoleczna.getText())) {
            wrt = ulepszenia.odpornoscSpolecznaP;
        } else if (tmp.equals(ulepszenia.respiratory.getText())) {
            wrt = ulepszenia.respiratoryP;
        } else if (tmp.equals(ulepszenia.leki.getText())) {
            wrt = ulepszenia.lekiP;
        } else if (tmp.equals(ulepszenia.szczepionka.getText())) {
            wrt = ulepszenia.szczepionkaP;
        } else if (tmp.equals(ulepszenia.szpitale.getText())) {
            wrt = ulepszenia.szpitaleP;
        }


    }

    public void settingCase(int wrt) {
        this.infectedCase = wrt;

        InfectedThread it = new InfectedThread(infectedCase);
        it.start();
        JLabel deaths = new JLabel(" ");
        JLabel infected = new JLabel(" ");
        JLabel recovered = new JLabel(" ");


        it.infected = infected;
        it.deaths = deaths;
        it.recovered = recovered;
        it.points = iloscMonet;

        ImageIcon idanger = new ImageIcon("src/GUI/Projekt2/Icons/danger.png");
        infected.setIcon(idanger);
        coinsy.add(infected);

        ImageIcon iskelet = new ImageIcon("src/GUI/Projekt2/Icons/skeleton.png");
        deaths.setIcon(iskelet);
        coinsy.add(deaths);

        ImageIcon irecovered = new ImageIcon("src/GUI/Projekt2/Icons/recovered.png");
        recovered.setIcon(irecovered);
        coinsy.add(recovered);


    }

    public void setPanelPanstwa() {
        JLabel label = new JLabel("Blokwanie dróg : ");

        JButton tajlandia = new JButton("Tajlandia");
        JButton polska = new JButton("Polska");
        JButton usa = new JButton("USA");
        JButton kanada = new JButton("Kanada");
        JButton australia = new JButton("Australia");
        JButton rosja = new JButton("Rosja");
        JButton brazylia = new JButton("Brazylia");
        JButton indie = new JButton("Indie");
        JButton madagaskar = new JButton("Madagaskar");
        JButton rpa = new JButton("RPA");
        JButton mali = new JButton("Mali");
        JButton somalia = new JButton("Somalia");
        JButton argentyna = new JButton("Argentyna");
        JButton peru = new JButton("Peru");
        JButton bialorus = new JButton("Bialorus");
        JButton bulgaria = new JButton("Bulgaria");
        JButton mongolia = new JButton("Mongolia");
        JButton iran = new JButton("Iran");
        JButton chiny = new JButton("Chiny");


        panstwa = new JPanel();

        panstwa.setLayout(new BoxLayout(panstwa, BoxLayout.Y_AXIS));
        panstwa.add(label);
        panstwa.add(usa);
        panstwa.add(kanada);
        panstwa.add(peru);
        panstwa.add(brazylia);
        panstwa.add(argentyna);
        panstwa.add(rpa);
        panstwa.add(mali);
        panstwa.add(somalia);
        panstwa.add(polska);
        panstwa.add(bialorus);
        panstwa.add(bulgaria);
        panstwa.add(iran);
        panstwa.add(mongolia);
        panstwa.add(rosja);
        panstwa.add(indie);
        panstwa.add(tajlandia);
        panstwa.add(madagaskar);
        panstwa.add(indie);
        panstwa.add(australia);
        panstwa.add(chiny);

        //tajlandia-mongolia
        tajlandia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (thaicount == 0) {
                    addPoints(500);
                    InfectedThread.range += 30;
                    InfectedThread.min += 50;
                    tajlandia.setEnabled(false);
                    thaicount++;
                }
            }
        });
        mongolia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (thaicount == 1) {
                    addPoints(350);
                    InfectedThread.range += 70;
                    InfectedThread.min += 90;
                    mongolia.setEnabled(false);
                    thaicount++;
                }
            }
        });
        //iran-rosja
        iran.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (irancount == 0) {
                    addPoints(450);
                    InfectedThread.range += 50;
                    InfectedThread.min += 50;
                    iran.setEnabled(false);
                    irancount++;
                }
            }
        });
        rosja.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (irancount == 1) {
                    addPoints(420);
                    InfectedThread.range += 67;
                    InfectedThread.min += 80;
                    rosja.setEnabled(false);
                    irancount++;
                }
            }
        });
        //chiny-indie
        chiny.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 0) {
                    addPoints(700);
                    InfectedThread.range += 120;
                    InfectedThread.min += 102;
                    chiny.setEnabled(false);
                    chinacount++;
                }
            }
        });
        indie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 1) {
                    addPoints(500);
                    InfectedThread.range += 150;
                    InfectedThread.min += 132;
                    indie.setEnabled(false);
                    chinacount++;
                }
            }
        });
        madagaskar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 2) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 132;
                    madagaskar.setEnabled(false);
                    chinacount++;
                }
            }
        });
        //somalia-mali
        somalia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 3) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 122;
                    somalia.setEnabled(false);
                    chinacount++;
                }
            }
        });
        mali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 4) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 122;
                    mali.setEnabled(false);
                    chinacount++;
                }
            }
        });
        rpa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 3) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 122;
                    rpa.setEnabled(false);
                    chinacount += 7;
                }
            }
        });
        brazylia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 10) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 122;
                    brazylia.setEnabled(false);
                    chinacount++;
                }
            }
        });
        argentyna.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 11) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 122;
                    argentyna.setEnabled(false);
                    chinacount++;
                }
            }
        });
        peru.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chinacount == 12) {
                    addPoints(350);
                    InfectedThread.range += 50;
                    InfectedThread.min += 122;
                    peru.setEnabled(false);
                    chinacount++;
                }
            }
        });


    }

    public void setPanelTransport() {
        transport = new JPanel();
        transport.setPreferredSize(new Dimension(90, 500));

        transport.setLayout(new GridLayout(5, 1));
        JLabel airplanel = new JLabel();
        JLabel trainl = new JLabel();
        JLabel carl = new JLabel();
        JLabel busl = new JLabel();
        JLabel shipl = new JLabel();


        ImageIcon airplane = new ImageIcon("src/GUI/Projekt2/Icons/plane.png");
        airplanel.setIcon(airplane);
        transport.add(airplanel);


        ImageIcon train = new ImageIcon("src/GUI/Projekt2/Icons/train.png");
        trainl.setIcon(train);
        transport.add(trainl);

        ImageIcon car = new ImageIcon("src/GUI/Projekt2/Icons/car.png");
        carl.setIcon(car);
        transport.add(carl);

        ImageIcon ship = new ImageIcon("src/GUI/Projekt2/Icons/ship.png");
        shipl.setIcon(ship);
        transport.add(shipl);

        ImageIcon bus = new ImageIcon("src/GUI/Projekt2/Icons/bus.png");
        busl.setIcon(bus);
        transport.add(busl);
    }


}
