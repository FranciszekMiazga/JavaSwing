package GUI.Projekt2.Ranking;

import javax.swing.*;
import java.awt.*;

public class RankingRenderer implements ListCellRenderer<String> {
    public String ww;
    public RankingModel rankingModel;


    @Override
    public Component getListCellRendererComponent(JList<? extends String> list, String value, int index, boolean isSelected, boolean cellHasFocus) {
        JLabel tmp = new JLabel(value);

        tmp.setOpaque(true);
        tmp.setText((String) value);

        if (index < 10)
            tmp.setBackground(Color.ORANGE);


        return tmp;
    }

}
