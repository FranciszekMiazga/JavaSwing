package GUI.Projekt2.Ranking;

import GUI.Projekt2.Gra;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RankingView extends JPanel {
    private JList<String> list = new JList<>();
    public List<String> e;
    public static String tmp3;

    public RankingView() {

        JPanel panel = new JPanel();
        setLayout(new BorderLayout());

        e = new ArrayList<>();


        RankingModel rank = new RankingModel(e);

        list.setModel(rank);
        list.setCellRenderer(new RankingRenderer());
        Gra.jList = list;


        JLabel etykieta = new JLabel("<html><div><strong>High Scores Ranking:</strong><br/><br/></div>" +
                "<div>Easy x1.0 , Medium x1.5 , Hard x2.0<br/></div></html>", SwingConstants.CENTER);
        panel.add(etykieta);
        panel.setBackground(new Color(204, 255, 255));
        panel.setPreferredSize(new Dimension(400, 80));
        add(panel, BorderLayout.PAGE_START);


        JScrollPane scroll = new JScrollPane(list);
        add(scroll, BorderLayout.CENTER);
        scroll.setBackground(new Color(255, 229, 204));


    }
}
