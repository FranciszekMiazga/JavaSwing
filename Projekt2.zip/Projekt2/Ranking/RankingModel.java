package GUI.Projekt2.Ranking;

import javax.swing.*;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.List;

public class RankingModel extends AbstractListModel<String> {
    public List<String> list;
    public String tmp;
    public static int wrt6;


    public RankingModel(List<String> list2) {
        this.list = list2;

        readRanking();


    }

    @Override
    public int getSize() {
        return list.size();
    }

    public void readRanking() {

        try {
            BufferedReader i = Files.newBufferedReader(Paths.get("src/GUI/Projekt2/rankingFile"));
            int length = 0;
            String line = "";
            while ((line = i.readLine()) != null) {
                length += line.length();

                add2(line);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void writeRanking() {
        try {

            Files.write(Paths.get("src/GUI/Projekt2/rankingFile"), list, Charset.defaultCharset());

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getElementAt(int index) {
        return list.get(index);
    }

    public void add(String tmp5, double wrt, LocalTime localTime, String level) {
        //readRanking();
        int index = list.size() + 1;


        tmp = index + ". " + tmp5 + ", " + wrt + ",    czas: " + localTime + ",    poziom trudnosci: " + level;

        list.add(getSize(), tmp);

        writeRanking();
        fireIntervalAdded(list, getSize(), getSize());


        index++;

    }

    public void add2(String wrt) {


        list.add(getSize(), wrt);
        fireIntervalAdded(list, getSize(), getSize());

    }
}
